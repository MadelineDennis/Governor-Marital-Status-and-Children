
## Project:  SOC302, Fall 2025, ANOVA
# Located:   Kline TCNJ Google Drive
# File Name: Kline-3.2-ANOVA-gov_married
# Date:      2025_7_11
# Who:       Zachary D. Kline

### Settings + Packages
setwd("/courses/STA145/dennism3")

## Load packages
# NOTE: Run base.R if these commands return an error!
library(readr)
library(dplyr)
library(ggplot2)
library(haven)
library(forcats)
library(psych)



###############################################################################
plot1 <- ggplot(number_of_children, aes(x = gov_married, y = score, color = gov_married, label = name)) +
  geom_point(size = 3) +
  ggtitle("number of children by Marital Status") +
  ylab("Score") +
  xlab("Marital Status") +
  geom_text(nudge_y = 1)
print(plot1)


# BOX PLOT
ggplot(number_of_children, aes(x = gov_married, y = score)) +
  geom_boxplot() +
  labs(title = "Box Plot of number of children by Marital Status",
       x = "Marital Status",
       y = "Math Score") +
  theme_minimal()

